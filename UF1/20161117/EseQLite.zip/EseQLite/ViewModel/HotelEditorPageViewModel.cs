﻿using EseQLite.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EseQLite.ViewModel
{
    class HotelEditorPageViewModel
    {

        private HotelViewModel mSelectedHotel;

        public HotelViewModel SelectedHotel
        {
            get { return mSelectedHotel; }
            set { mSelectedHotel = value; }
        }


        private ObservableCollection<HotelViewModel> mHotels;

        public ObservableCollection<HotelViewModel> Hotels
        {
            get { return mHotels; }
            set { mHotels = value; }
        }

    }
}
