﻿using EseQLite.Model;
using EseQLite.ViewModel.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EseQLite.ViewModel
{
    public class HotelViewModel : NotificationBase<Hotel>
    {
        public HotelViewModel(Hotel h = null) : base(h) { }

        public string Nom
        {
            get { return This.Nom; }
            set {
                SetProperty(This.Nom, value, () => This.Nom = value);
            }
        }

        public Int64 Codi
        {
            get { return This.Codi; }
            set
            {
                SetProperty(This.Codi, value, () => This.Codi = value);
            }
        }

        public string Poblacio
        {
            get { return This.Poblacio; }
            set
            {
                SetProperty(This.Poblacio, value, () => This.Poblacio = value);
            }
        }

}
}
